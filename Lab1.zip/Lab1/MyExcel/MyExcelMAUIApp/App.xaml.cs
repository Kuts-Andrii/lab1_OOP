namespace MyExcelMAUIApp;

public partial class App : Application
{
    private const string WindowTitle = "MyExcel — Куць Андрій, К-28";
    private const double WindowWidth = 1280;
    private const double WindowHeight = 800;
    private const double MinWindowWidth = 800;
    private const double MinWindowHeight = 500;

    public App()
    {
        InitializeComponent();
        UserAppTheme = AppTheme.Dark;
    }

    protected override Window CreateWindow(IActivationState? activationState) =>
        new(new AppShell())
        {
            Title = WindowTitle,
            Width = WindowWidth,
            Height = WindowHeight,
            MinimumWidth = MinWindowWidth,
            MinimumHeight = MinWindowHeight,
        };
}
